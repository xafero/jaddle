var cmd = ctx.require('app/core/cli.js');
cmd(ctx.args);